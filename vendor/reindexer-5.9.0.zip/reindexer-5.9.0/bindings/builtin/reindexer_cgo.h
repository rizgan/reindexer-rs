#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void reindexer_enable_go_logger(void);
void reindexer_disable_go_logger(void);

#ifdef __cplusplus
}
#endif
