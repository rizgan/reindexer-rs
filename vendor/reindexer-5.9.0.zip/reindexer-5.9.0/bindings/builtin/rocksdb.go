// +build rocksdb

package builtin

// #cgo LDFLAGS: -lrocksdb -lz
import "C"
