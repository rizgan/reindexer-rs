#pragma once

namespace reindexer {
extern const char* stop_words_ru[];
extern const char* stop_words_en[];
}  // namespace reindexer